#!/bin/bash
java -jar CSS.jar
